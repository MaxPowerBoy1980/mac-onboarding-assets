#!/bin/zsh

# Simple SwiftDialog Welcome

# Hent brugerens navn
current_user=$(stat -f%Su /dev/console)

# Hent OS version
os_version=$(sw_vers -productVersion)

# Kør dialog
/usr/local/bin/dialog \
    --title "Welcome, $current_user!" \
    --message "Your Mac is running macOS $os_version.\n\nWe are now preparing it for secure setup. Please stay connected!" \
    --icon SF=person.crop.circle.badge.checkmark \
    --mini \
    --position center
