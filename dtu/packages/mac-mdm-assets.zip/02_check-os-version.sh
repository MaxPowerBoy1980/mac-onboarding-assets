#!/bin/zsh

#############################################
# 02_check-os-version.sh
# Verifies minimum macOS version requirement
#############################################

# 📂 Load logging module
LOGGING_SCRIPT="/usr/local/MDMAssets/Scripts/logging.sh"

if [ -f "$LOGGING_SCRIPT" ]; then
    source "$LOGGING_SCRIPT"
    log "✅ Logging module loaded."
else
    echo "❌ ERROR: Logging module not found. Exiting."
    exit 1
fi

# ✏️ SETTINGS
MINIMUM_VERSION="13.0"

# 🔍 Get current macOS version
CURRENT_VERSION=$(sw_vers -productVersion)

log "Detected macOS version: $CURRENT_VERSION"
log "Required minimum version: $MINIMUM_VERSION"

# 📈 Compare versions
autoload is-at-least
if is-at-least "$MINIMUM_VERSION" "$CURRENT_VERSION"; then
    log "✅ macOS version is sufficient."
else
    log "❌ macOS version too low. Exiting."
    exit 1
fi
